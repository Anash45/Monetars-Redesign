Homepage //new slider create//
Earn //new card create
Leaderbord
Profile //
leaders //

Withdraw //
Reward //
Unavailable //
Privacy Policy //
Terms of service //
Imprint //
About us //
Blog //
Blog Details //
Contact //
FAQ //
